// ============================================================================
// File: ccar.cpp
// ============================================================================
// This is the implementation file for CCar.
// ============================================================================

#include    <iostream>
#include	<string>
using namespace std;

#include    "cvehicle.h"
#include    "ccar.h"



// ==== Default Constructor ===================================================
//
// The default constructor sets make and model to "Honda" and "Civic"
// respectively. 
// It also sets vehicle name to "Rumble", fuel type to G>asPowered,
// fuel level to 75%, 53000 miles, transmission to M>anual, and 2 number of
// doors
//
// ============================================================================

???



// ==== Type Constructor ======================================================
//
// The type constructor assigns the values passed as arguments during
// declaration
//
// ============================================================================

???




// 2 virtual functions implmentation below
???