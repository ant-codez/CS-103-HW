// ============================================================================
// File: ctruck.cpp
// ============================================================================
// This is the implementation file for CTruck.
// ============================================================================

#include    <iostream>
#include	<string>
using namespace std;

#include    "cvehicle.h"
#include    "ccar.h"
#include    "ctruck.h"



// ==== Default Constructor ===================================================
//
// The default constructor sets make and model to "Ford" and "F150"
// respectively. 
// It also sets vehicle name to "Turbofire", fuel type to D>iesel,
// fuel level to 37%, 210154 miles, transmission to A>utomatic, 4 number of
// doors, cab size is single, bed size is standard, and it is not four-wheel-
// drive.
//
// ============================================================================

???



// ==== Type Constructor ======================================================
//
// The type constructor assigns the values passed as arguments during
// declaration
//
// ============================================================================

???




// 2 virtual functions implmentation below
???